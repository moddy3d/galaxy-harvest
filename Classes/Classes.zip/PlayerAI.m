//
//  PlayerAI.m
//  CoinCatch
//
//  Created by Richard Lei on 11-01-12.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "PlayerAI.h"


@implementation PlayerAI

@end
