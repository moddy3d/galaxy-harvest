//
//  MenuScene.m
//  CoinCatch
//
//  Created by Richard Lei on 11-01-06.
//  Copyright 2011 Creative Inventory Ltd. All rights reserved.
//

#import "MenuScene.h"
#import "LoadingScene.h"

@implementation MenuScene

+ (id) scene
{
	CCScene* scene = [CCScene node];
	CCLayer* layer = [MenuScene node];
	[scene addChild:layer];
	return scene;
}

//
// INTERACTION METHODS
//

- (CGPoint) locationFromTouch:(UITouch*)touch
{
	CGPoint touchLocation = [touch locationInView: [touch view]]; return [[CCDirector sharedDirector] convertToGL:touchLocation];
}

- (CGPoint) locationFromTouches:(NSSet*)touches 
{
	return [self locationFromTouch:[touches anyObject]];
}


- (BOOL) ccTouchBegan:(UITouch*)touch withEvent:(UIEvent *)event
{
	return YES;
}

- (void) ccTouchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
	
}




//
// MENU METHODS
//

- (void) menuSwitch:(id) sender
{
	TagID aTag = [sender tag];
	switch (aTag) {
		case EnglishButtonID:
			[mpLayer switchTo:1];
			break;
		case ChineseButtonID:
			[mpLayer switchTo:1];
			break;
		case StartGameButtonID:
			[[CCDirector sharedDirector] replaceScene:[LoadingScene sceneWithTargetScene:TargetSceneGameScene]];
			break;
		case OptionsButtonID:
			[mpLayer switchTo:2];
			break;
		default:
			// do nothing
			break;
	}	
}


- (void) optionMenuSelector:(id) sender
{
	TagID aTag = [sender tag];
	switch (aTag) {
		case soundOnButtonID:
			// turn on sound
			break;
		case soundOffButtonID:
			// turn off sound
			break;
		case musicOnButtonID:
			// turn on music
			break;
		case musicOffButtonID:
			// turn off music
			break;
		case chineseOnButtonID:
			// turn on chinese lang
			break;
		case englishOnButtonID:
			// turn off english lang
			break;
		case backToMainButtonID:
			[mpLayer switchTo:1];
			break;
		default:
			// do nothing;
			break;
	}	
}



- (void) update:(ccTime)delta
{
	
}


// 
// INIT
//

- (id) init
{
	if ((self = [super init]))
	{
		CCLOG(@"%@: %@", NSStringFromSelector(_cmd), self);
		
		CGSize screenSize = GameOptions.screenSize;
		
		NSString* filePathString = nil;
		switch (GameOptions.typeOfDevice) {
			case IS_IPHONE_3_DEVICE:
				filePathString = [NSString stringWithString:@"textureFiles/lowRes/"];
				break;
			case IS_IPHONE_4_DEVICE:
				filePathString = [NSString stringWithString:@"textureFiles/retina/"];
				break;
			case IS_IPAD_DEVICE:
				filePathString = [NSString stringWithString:@"textureFiles/iPad/"];
				break;
			default:
				break;
		}
		
		// Add language selection layer
		languageSelectionLayer = [CCLayer node];
		// Add language selection buttons
		NSString* englishButtonFilePathString = [filePathString stringByAppendingString:@"mainMenu/buttons/englishButton.png"];
		englishButton = [CCMenuItemImage itemFromNormalImage:englishButtonFilePathString selectedImage:englishButtonFilePathString disabledImage:englishButtonFilePathString
													  target:self selector:@selector(menuSwitch:)];
		englishButton.tag = EnglishButtonID;
		
		NSString* chineseButtonFilePathString = [filePathString stringByAppendingString:@"mainMenu/buttons/chineseButton.png"];
		chineseButton = [CCMenuItemImage itemFromNormalImage:chineseButtonFilePathString selectedImage:chineseButtonFilePathString disabledImage:chineseButtonFilePathString
													  target:self selector:@selector(menuSwitch:)];
		chineseButton.position = CGPointMake(0, -screenSize.height/8);
		chineseButton.tag = ChineseButtonID;
		
		CCMenu* languageMenu = [CCMenu menuWithItems:englishButton,chineseButton,nil];
		
		[languageSelectionLayer addChild:languageMenu];

		
		
		// Add main menu layer
		mainMenuLayer = [CCLayer node];
		
		NSString* startButtonFilePathString = [filePathString stringByAppendingString:@"mainMenu/buttons/startButton.png"];
		startButton = [CCMenuItemImage itemFromNormalImage:startButtonFilePathString selectedImage:startButtonFilePathString disabledImage:startButtonFilePathString 
													target:self selector:@selector(menuSwitch:)];
		startButton.tag = StartGameButtonID;
		
		NSString* optionsButtonFilePathString = [filePathString stringByAppendingString:@"mainMenu/buttons/optionsButton.png"];
		optionsButton = [CCMenuItemImage itemFromNormalImage:optionsButtonFilePathString selectedImage:optionsButtonFilePathString disabledImage:optionsButtonFilePathString 
													target:self selector:@selector(menuSwitch:)];
		optionsButton.tag = OptionsButtonID;
		optionsButton.position = CGPointMake(0, -screenSize.height/8);
		
		CCMenu* mainMenu = [CCMenu menuWithItems:startButton,optionsButton,nil];
		
		[mainMenuLayer addChild:mainMenu];
		
		
		// Add options menu layer
		optionsMenuLayer = [CCLayer node];
		
		// SOUND TOGGLE BUTTON
				NSString* soundOnButtonFilePathString = [filePathString stringByAppendingString:@"mainMenu/buttons/soundOnButton.png"];
		CCMenuItemImage* soundOn = [CCMenuItemImage itemFromNormalImage:soundOnButtonFilePathString selectedImage:soundOnButtonFilePathString disabledImage:soundOnButtonFilePathString
									target:self selector:@selector(optionMenuSelector:)];
		soundOn.tag = soundOnButtonID;
		
		NSString* soundOffButtonFilePathString = [filePathString stringByAppendingString:@"mainMenu/buttons/soundOffButton.png"];
		CCMenuItemImage* soundOff = [CCMenuItemImage itemFromNormalImage:soundOffButtonFilePathString selectedImage:soundOffButtonFilePathString disabledImage:soundOffButtonFilePathString
									target:self selector:@selector(optionMenuSelector:)];
		soundOff.tag = soundOffButtonID;
		soundToggle = [CCMenuItemToggle itemWithTarget:self selector:@selector(optionMenuSelector:) items:soundOn,soundOff,nil];
		
		// MUSIC TOGGLE BUTTON
		NSString* musicOnButtonFilePathString = [filePathString stringByAppendingString:@"mainMenu/buttons/musicOnButton.png"];
		CCMenuItemImage* musicOn = [CCMenuItemImage itemFromNormalImage:musicOnButtonFilePathString selectedImage:musicOnButtonFilePathString disabledImage:musicOnButtonFilePathString
									target:self selector:@selector(optionMenuSelector:)];
		musicOn.tag = musicOnButtonID;
		
		NSString* musicOffButtonFilePathString = [filePathString stringByAppendingString:@"mainMenu/buttons/musicOffButton.png"];
		CCMenuItemImage* musicOff = [CCMenuItemImage itemFromNormalImage:musicOffButtonFilePathString selectedImage:musicOffButtonFilePathString disabledImage:musicOffButtonFilePathString
									 target:self selector:@selector(optionMenuSelector:)];
		musicOff.tag = musicOffButtonID;
		
		musicToggle = [CCMenuItemToggle itemWithTarget:self selector:@selector(optionMenuSelector:) items:musicOn,musicOff,nil];
		
		// CREDITS BUTTON
		NSString* creditsButtonFilePathString = [filePathString stringByAppendingString:@"mainMenu/buttons/creditsButton.png"];
		creditsButton = [CCMenuItemImage itemFromNormalImage:creditsButtonFilePathString selectedImage:creditsButtonFilePathString disabledImage:creditsButtonFilePathString
									target:self selector:@selector(optionMenuSelector:)];
		creditsButton.tag = creditsButtonID;
		
		// RESET SCORES BUTTON
		NSString* resetScoreButtonFilePathString = [filePathString stringByAppendingString:@"mainMenu/buttons/resetScoreButton.png"];
		resetScoreButton = [CCMenuItemImage itemFromNormalImage:resetScoreButtonFilePathString selectedImage:resetScoreButtonFilePathString disabledImage:resetScoreButtonFilePathString
									target:self selector:@selector(optionMenuSelector:)];
		resetScoreButton.tag = resetScoreButtonID;
		
		// LANGUAGE TOGGLE
		NSString* chineseOnButtonFilePathString = [filePathString stringByAppendingString:@"mainMenu/buttons/chineseButton.png"];
		CCMenuItemImage* chineseOn = [CCMenuItemImage itemFromNormalImage:chineseOnButtonFilePathString selectedImage:chineseOnButtonFilePathString disabledImage:chineseOnButtonFilePathString
									  target:self selector:@selector(optionMenuSelector:)];
		chineseOn.tag = chineseOnButtonID;
		
		NSString* englishOnButtonFilePathString = [filePathString stringByAppendingString:@"mainMenu/buttons/englishButton.png"];
		CCMenuItemImage* englishOn = [CCMenuItemImage itemFromNormalImage:englishOnButtonFilePathString selectedImage:englishOnButtonFilePathString disabledImage:englishOnButtonFilePathString
									  target:self selector:@selector(optionMenuSelector:)];
		englishOn.tag = englishOnButtonID;
		
		languageToggle = [CCMenuItemToggle itemWithTarget:self selector:@selector(optionMenuSelector:) items:chineseOn,englishOn,nil];
			
		// BACK BUTTON
		NSString* backToMainButtonFilePathString = [filePathString stringByAppendingString:@"mainMenu/buttons/backToMainButton.png"];
		backToMainMenuButton = [CCMenuItemImage itemFromNormalImage:backToMainButtonFilePathString selectedImage:backToMainButtonFilePathString disabledImage:backToMainButtonFilePathString
															 target:self selector:@selector(optionMenuSelector:)];
		backToMainMenuButton.tag = backToMainButtonID;
	
		
		// menu & layer setup
		
		CCMenu* optionsMenu = [CCMenu menuWithItems:soundToggle,musicToggle,creditsButton,resetScoreButton,languageToggle,backToMainMenuButton,nil];
		[optionsMenu alignItemsVerticallyWithPadding:screenSize.height/24];
		[optionsMenuLayer addChild:optionsMenu];
		
		
		// Add layers to multiplex layer;
		mpLayer = [CCMultiplexLayer layerWithLayers:languageSelectionLayer,mainMenuLayer,optionsMenuLayer, nil];
		[self addChild:mpLayer];
		
		// Add Game title
	
		gameTitle = [CCLabelTTF labelWithString:@"COIN CATCHER" fontName:@"Arial" fontSize:30];
		gameTitle.position = CGPointMake(screenSize.width/2, screenSize.height*5/6);
		
		[self addChild:gameTitle z:GUILayer];
		
		

		
		// Retain
		[mpLayer retain];

		
		// Schedule Update
		
		[[CCTouchDispatcher sharedDispatcher] addTargetedDelegate:self priority:0 swallowsTouches:YES];
		[self scheduleUpdate];
	//	[[CCScheduler sharedScheduler] scheduleUpdateForTarget:mpLayer priority:1 paused:NO];		
		//[[CCScheduler sharedScheduler] scheduleUpdateForTarget:self priority:0 paused:NO];		
	}
	return self;
}

- (void) dealloc
{
	CCLOG(@"%@: %@", NSStringFromSelector(_cmd), self);
	[mpLayer release];
	[super dealloc];
}



@end
