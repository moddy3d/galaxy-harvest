//
//  ItemFactory.h
//  CoinCatch
//
//  Created by Richard Lei on 11-01-07.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"
#import "GameConfig.hpp"


#define NUMBER_OF_DIFFERENT_ITEMS 8

@interface ItemFactory : NSObject 
{
	// Chance variables
	float chanceForNothing;
	
	float chanceForBronzeCoin;
	float chanceForSilverCoin;
	float chanceForGoldCoin;
	float chanceForJadeCoin;
	float chanceForIceCoin;
	float chanceForRedBag;
	float chanceForPoop;
	float chanceForTimeExtension;
	
	float chanceArray[NUMBER_OF_DIFFERENT_ITEMS];
	
	CGPoint rangeArray[NUMBER_OF_DIFFERENT_ITEMS];
	
	//time variables
	float timeSinceLastSpawn;
	
}

@property float chanceForNothing;
@property float chanceForBronzeCoin;
@property float chanceForSilverCoin;
@property float chanceForGoldCoin;
@property float chanceForJadeCoin;
@property float chanceForIceCoin;
@property float chanceForRedBag;
@property float chanceForPoop;
@property float chanceForTimeExtension;
@property float timeSinceLastSpawn;

- (TypeOfItem) itemToSpawn:(float)realTime;

@end
