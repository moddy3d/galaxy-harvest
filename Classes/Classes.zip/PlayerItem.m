//
//  PlayerItem.m
//  CoinCatch
//
//  Created by Richard Lei on 11-01-07.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "PlayerItem.h"


@implementation PlayerItem
@synthesize itemType, worth, tagNo, edibleTimer, spawnPosition, velocity, itemSprite, affectedByForces;



//
// SET Default file name
//

- (NSString*) returnItemFileName:(NSString*)folderString
{
	return [folderString stringByAppendingString:@"item_bronzeCoin0.png"];
}

// SET Default item type

- (void) setItemType
{
	itemType = BronzeCoinItemID;
}

// SET Default item worth

- (void) setItemWorth
{
	worth = BRONZE_COIN_WORTH;
}



//
// RANDOM Spawn Methods
//

- (void) randomSpawnFromTop
{
	// Get Screen size
	CGSize screenSize = [[CCDirector sharedDirector] winSize];
	
	// Set up Spawn Position
	spawnPosition = CGPointMake(CCRANDOM_0_1() * screenSize.width, screenSize.height*1.1);
	
	// Set up Target vector
	CGPoint spawnTowardsVector = CGPointMake(CCRANDOM_0_1() *screenSize.width, CCRANDOM_0_1() * screenSize.height/2);
	float xPosDifference = spawnTowardsVector.x - spawnPosition.x;
	float yPosDifference = spawnTowardsVector.y - spawnPosition.y;
	
	//Aim coin at vector
	velocity = CGPointMake(0.0 * xPosDifference, 0.4 * yPosDifference);
}

+ (id) itemWithParentNode:(CCNode*)parentNode randomSpawnMethod:(WhereToSpawnItem)method isAffectedByForces:(BOOL)affected edibleInTime:(float)edibleTime
{
	return [[[self alloc] initWithParentNode:parentNode randomSpawnMethod:method isAffectedByForces:affected edibleInTime:edibleTime] autorelease];
}

- (id) initWithParentNode:(CCNode*)parentNode randomSpawnMethod:(WhereToSpawnItem)method isAffectedByForces:(BOOL)affected edibleInTime:(float)edibleTime
{
	if ((self = [super init]))
	{
		// Set type of item
		[self setItemType];	
		
		// Set item worth
		[self setItemWorth];
		
		//Select Image file based on type
		NSString* folderString = nil;
		switch (GameOptions.typeOfDevice) {
			case IS_IPHONE_3_DEVICE:
				folderString = [NSString stringWithString:@"textureFiles/lowRes/item/"];
				break;
			case IS_IPHONE_4_DEVICE:
				folderString = [NSString stringWithString:@"textureFiles/retina/item/"];
								break;
			case IS_IPAD_DEVICE:
				folderString = [NSString stringWithString:@"textureFiles/iPad/item/"];
				break;
			default:
				break;
		}
		NSString* fileName = [self returnItemFileName:folderString];
		
		// Is this item affected by external forces?
		affectedByForces = affected;
		
		// add tag number
		tagNo = GameCounts.itemCount;
		
		// add edible timer
		edibleTimer = edibleTime;
		
		// Set up type of random spawn Position & velocity
		switch (method) {
			case SpawnItemFromTop:
				[self randomSpawnFromTop];
				break;
			default:
				[self randomSpawnFromTop];
				break;
		}
		
		itemSprite = [CCSprite spriteWithFile:fileName];
		
		itemSprite.position = spawnPosition;

		[parentNode addChild:itemSprite z:ItemLayer tag:tagNo];
		
		// Increment global item count
		GameCounts.itemCount++;
	}
	return self;
}

//
// DEFINED Spawn Methods
//
 
- (void) definedSpawnPosition:(CGPoint)definedPos definedSpawnVelocity:(CGPoint)definedVel 
{
	spawnPosition = definedPos;
	velocity = definedVel;
	itemSprite.position = definedPos;
}

+ (id) itemWithParentNode:(CCNode*)parentNode initPosition:(CGPoint)definedPos initVelocity:(CGPoint)definedVel isAffectedByForces:(BOOL)affected edibleInTime:(float)edibleTime
{
	return [[[self alloc] initWithParentNode:parentNode initPosition:definedPos initVelocity:definedVel isAffectedByForces:affected edibleInTime:edibleTime] autorelease];
}

- (id) initWithParentNode:(CCNode*)parentNode initPosition:(CGPoint)definedPos initVelocity:(CGPoint)definedVel isAffectedByForces:(BOOL)affected edibleInTime:(float)edibleTime
{
	if ((self = [super init]))
	{
		// Set type of item
		[self setItemType];
		
		// Set item worth
		[self setItemWorth];
		
		//Select Image file based on type
		NSString* folderString = nil;
		switch (GameOptions.typeOfDevice) {
			case IS_IPHONE_3_DEVICE:
				folderString = [NSString stringWithString:@"textureFiles/lowRes/item/"];
				break;
			case IS_IPHONE_4_DEVICE:
				folderString = [NSString stringWithString:@"textureFiles/retina/item/"];
				break;
			case IS_IPAD_DEVICE:
				folderString = [NSString stringWithString:@"textureFiles/iPad/item/"];
				break;
			default:
				break;
		}
		NSString* fileName = [self returnItemFileName:folderString];
		
		// Is this item affected by external forces?
		affectedByForces = affected;
		
		// Add tag number
		tagNo = GameCounts.itemCount;
		
		// add edible timer
		edibleTimer = edibleTime;
		
		itemSprite = [CCSprite spriteWithFile:fileName];
		
		// Set up default spawn Position & velocity
		[self definedSpawnPosition:definedPos definedSpawnVelocity:definedVel];
		
		[parentNode addChild:itemSprite z:ItemLayer tag:tagNo];
		
		// Increment global item count
		GameCounts.itemCount++;
	}
	return self;
}


- (void) dealloc
{
	[super dealloc];	
}


@end
