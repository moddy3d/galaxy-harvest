//
//  GameScene.m
//  CoinCatch
//
//  Created by Richard Lei on 11-01-06.
//  Copyright 2011 Creative Inventory Ltd. All rights reserved.
//

#import "GameScene.h"
#import "LoadingScene.h"


@implementation GameScene

@synthesize stateOfGame, realTimeElapsed, gameTimer;

+ (id) scene
{
	CCScene* scene = [CCScene node];
	CCLayer* layer = [GameScene node];
	[scene addChild:layer];
	return scene;
}


//
// OFF SCREEN INDICATOR
//

- (void) showOffScreenIndicatorIfOffScreen:(PlayerCharacter*)Player
{
	// If Player's Y Position is greater than the screen's height plus the Player's character's height * 3/4 then he is offscreen
	if (Player.isOffScreen == YES)
	{
		if (Player.playerNumber == 1) {
			Player1OffScreenIndicator.position = CGPointMake(Player.currentPosition.x, GameOptions.screenSize.height - 20*_GAME_CONSTANT); 
		}
		else if (Player.playerNumber == 2) {
			Player2OffScreenIndicator.position = CGPointMake(Player.currentPosition.x, GameOptions.screenSize.height - 20*_GAME_CONSTANT); 
		}
	}
	else {
		if (Player.playerNumber == 1) {
			Player1OffScreenIndicator.position = CGPointMake(0, GameOptions.screenSize.height * 2); 
		}
		else if (Player.playerNumber == 2) {
			Player2OffScreenIndicator.position = CGPointMake(0, GameOptions.screenSize.height * 2); 
		}
		
	}

}


//
// HELPER METHODS
//

- (NSString*) timeToString:(float)time
{
	return [[NSString stringWithFormat:@"%f",time] substringToIndex:4];
}

//
// INTERACTION HANDLERS
//


- (CGPoint) locationFromTouch:(UITouch*)touch
{
	CGPoint touchLocation = [touch locationInView: [touch view]]; 
	return [[CCDirector sharedDirector] convertToGL:touchLocation];
}

- (CGPoint) locationFromTouches:(NSSet*)touches 
{
	return [self locationFromTouch:[touches anyObject]];
}

- (BOOL) ccTouchBegan:(UITouch*)touch withEvent:(UIEvent *)event
{
	
	NSAssert([[self getChildByTag:PoundDownButtonID] isKindOfClass:[CCSprite class]], @"node is not a CCSprite!");
	
	CCSprite* poundButtonSprite = (CCSprite*) [self getChildByTag:PoundDownButtonID];
	
	float poundButtonRadius = ([poundButtonSprite texture].contentSize.width)/2;
	
	CGPoint touchLoc = [self locationFromTouch:touch];
	
	float distanceBetween = ccpDistance(touchLoc, poundButtonSprite.position);
	
	if (distanceBetween < poundButtonRadius) 
	{
		[physicsHandler poundDownWithPlayer:Player1];
		return YES;
	}
	else {
		return NO;
	}
}


- (void) ccTouchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
	
}
-(void) ccTouchesMoved:(NSSet *)touches withEvent:(UIEvent *)event {
    
}
-(void) ccTouchesEnded:(NSSet *)touches withEvent:(UIEvent *)event {
    
}



- (void) accelerometer:(UIAccelerometer *)accelerometer didAccelerate:(UIAcceleration *)acceleration
{
	float deceleration = 0.4;
	float sensitivity = 1200.0 - fabs(Player1.velocity.x)*0.3;
	
	[physicsHandler accelerateXWithCharacter:Player1 accelerometerX:acceleration.x decelerate:deceleration accelerometerSensitivity:sensitivity];
}







//
// ITEM SPAWN HANDLERS
//

- (void) callItemFactory
{
	if (stateOfGame == GameStateRunning) {
		TypeOfItem itemRecieved = [myItemFactory itemToSpawn:realTimeElapsed];
		if (itemRecieved != NullItemID) {
			PlayerItem* newItem;
			switch (itemRecieved) {
				case BronzeCoinItemID:
					newItem = [BronzeCoinItem itemWithParentNode:self randomSpawnMethod:SpawnItemFromTop isAffectedByForces:NO edibleInTime:0];
					break;
					
				case SilverCoinItemID:
					newItem = [SilverCoinItem itemWithParentNode:self randomSpawnMethod:SpawnItemFromTop isAffectedByForces:NO edibleInTime:0];
					break;
					
				case GoldCoinItemID:
					newItem = [GoldCoinItem itemWithParentNode:self randomSpawnMethod:SpawnItemFromTop isAffectedByForces:NO edibleInTime:0];
					break;

				case JadeCoinItemID:
					newItem = [JadeCoinItem itemWithParentNode:self randomSpawnMethod:SpawnItemFromTop isAffectedByForces:NO edibleInTime:0];
					break;

				case IceCoinItemID:
					newItem = [IceCoinItem itemWithParentNode:self randomSpawnMethod:SpawnItemFromTop isAffectedByForces:NO edibleInTime:0];
					break;

				case RedBagItemID:
					newItem = [RedBagItem itemWithParentNode:self randomSpawnMethod:SpawnItemFromTop isAffectedByForces:NO edibleInTime:0];
					break;

				case PoopItemID:
					newItem = [PoopItem itemWithParentNode:self randomSpawnMethod:SpawnItemFromTop isAffectedByForces:NO edibleInTime:0];
					break;
					
				case ExtendTimeItemID:
					newItem = [ExtendTimeItem itemWithParentNode:self randomSpawnMethod:SpawnItemFromTop isAffectedByForces:NO edibleInTime:0];
					break;
					
				default:
					newItem = [BronzeCoinItem itemWithParentNode:self randomSpawnMethod:SpawnItemFromTop isAffectedByForces:NO edibleInTime:0];
					break;
					
			}

			[itemArray addObject:newItem];
		}
	}
}




//
// GAME OVER HANDLER
//

- (void) gameFinishedSelector:(id) sender
{
	TagID aTag = [sender tag];
	switch (aTag) {
		case retryButtonID:
			//restart game
			[[CCDirector sharedDirector] replaceScene:[LoadingScene sceneWithTargetScene:TargetSceneGameScene]];
			break;
		case backToMainButtonID:
			//back to main menu
			[[CCDirector sharedDirector] replaceScene:[LoadingScene sceneWithTargetScene:TargetSceneMenuScene]];
		default:
			// do nothing;
			break;
	}	
}




- (void) showHighScoresAndOptions
{
	
	CCLayerColor* colorLayer = [CCLayerColor layerWithColor:ccc4(0, 0, 0, 150)];
	
	CCLabelTTF* Player1FinalScoreDisplay = [CCLabelTTF labelWithString:[NSString stringWithFormat:@"PLAYER 1: %i",Player1.score] fontName:@"Arial" fontSize:30];
	Player1FinalScoreDisplay.position = CGPointMake(GameOptions.screenSize.width/3, GameOptions.screenSize.height*4/5);
	[colorLayer addChild:Player1FinalScoreDisplay];
	
	CCLabelTTF* Player2FinalScoreDisplay = [CCLabelTTF labelWithString:[NSString stringWithFormat:@"PLAYER 2: %i",Player2.score] fontName:@"Arial" fontSize:30];
	Player2FinalScoreDisplay.position = CGPointMake(GameOptions.screenSize.width*2/3, GameOptions.screenSize.height*4/5);
	[colorLayer addChild:Player2FinalScoreDisplay];
	
	
	NSString* filePathString;
	switch (GameOptions.typeOfDevice) {
		case IS_IPHONE_3_DEVICE:
			filePathString = [NSString stringWithString:@"textureFiles/lowRes/"];
			break;
		case IS_IPHONE_4_DEVICE:
			filePathString = [NSString stringWithString:@"textureFiles/retina/"];
			break;
		case IS_IPAD_DEVICE:
			filePathString = [NSString stringWithString:@"textureFiles/iPad/"];
			break;
		default:
			filePathString = [NSString stringWithString:@"textureFiles/lowRes/"];
			break;
	}	
	
	
	// RETRY BUTTON
	
	NSString* retryButtonFilePathString = [filePathString stringByAppendingString:@"mainMenu/buttons/retryButton.png"];
	CCMenuItemImage* retryButton = [CCMenuItemImage itemFromNormalImage:retryButtonFilePathString selectedImage:retryButtonFilePathString disabledImage:retryButtonFilePathString
																 target:self selector:@selector(gameFinishedSelector:)];
	retryButton.tag = retryButtonID;
	
	
	
	// BACK BUTTON
	NSString* backToMainMenuFilePathString = [filePathString stringByAppendingString:@"mainMenu/buttons/backToMainButton.png"];
	CCMenuItemImage* backToMainMenuButton = [CCMenuItemImage itemFromNormalImage:backToMainMenuFilePathString selectedImage:backToMainMenuFilePathString disabledImage:backToMainMenuFilePathString
																		  target:self selector:@selector(gameFinishedSelector:)];
	backToMainMenuButton.tag = backToMainButtonID;
	
	CCMenu* gameFinishedMenu = [CCMenu menuWithItems:retryButton,backToMainMenuButton,nil];
	
	[gameFinishedMenu alignItemsVerticallyWithPadding:GameOptions.screenSize.height/24];
	
	CCLayer* gameFinishOptionsLayer = [CCLayer node];
	
	[gameFinishOptionsLayer addChild:gameFinishedMenu z:10];
	
	
	
	[self addChild:colorLayer z:GUILayer];
	[self addChild:gameFinishOptionsLayer z:GUILayer+1];
}


- (void) gameOver
{
	stateOfGame = GameStateFinished;
	[self showHighScoresAndOptions];
}




//
// UPDATE TIMERS & SCORE
//

- (void) updateScore:(PlayerCharacter*)Player
{
	if (Player.playerNumber == 1)
	[Player1ScoreDisplay setString:[NSString stringWithFormat:@"%i",Player.score]];
	else if (Player.playerNumber == 2)
	[Player2ScoreDisplay setString:[NSString stringWithFormat:@"%i",Player.score]];
}


- (void) updateRealTime:(ccTime)delta
{
	realTimeElapsed += delta;	
}

- (void) updateGameTimer:(ccTime)delta
{
	if (stateOfGame == GameStateRunning) {
		gameTimer -= delta;	
		[gameTimeDisplay setString:[self timeToString:gameTimer]];
		if (gameTimer < 0) {
			[self gameOver];
		}
	}
}

//
// UPDATE METHOD
//

- (void) update:(ccTime)delta
{
	[brain feedSelf:Player2 feedEnemy:Player1 feedItems:itemArray feedTime:delta motionHandler:physicsHandler];
	
	[self updateRealTime:delta];
	[self updateGameTimer:delta];
	
	[physicsHandler moveCharacter:delta whatPlayer:Player1 gameState:stateOfGame];
	[physicsHandler moveCharacter:delta whatPlayer:Player2 gameState:stateOfGame];
		
	[physicsHandler moveItems:delta items:itemArray gameState:stateOfGame];
	
	[physicsHandler checkPlayerToPlayerCollision:delta playerOne:Player1 playerTwo:Player2 gameState:stateOfGame items:itemArray gameNode:self];
	
	[physicsHandler checkPlayerGroundCollision:Player1 gameState:stateOfGame];
	[physicsHandler checkPlayerGroundCollision:Player2 gameState:stateOfGame];
	
	[physicsHandler checkItemGroundCollision:itemArray gameState:stateOfGame gameNode:self];
	
	[physicsHandler checkItemCollision:Player1 items:itemArray gameState:stateOfGame gameNode:self];
	[physicsHandler checkItemCollision:Player2 items:itemArray gameState:stateOfGame gameNode:self];
	
	[self updateScore:Player1];
	[self updateScore:Player2];
	
	[self showOffScreenIndicatorIfOffScreen:Player1];
	[self showOffScreenIndicatorIfOffScreen:Player2];
	
	[self callItemFactory];
}


 

//
// INITIAL SEQUENCE
//



- (void) initialSequence
{	
	// Setup game state
	stateOfGame = GameStateRunning;
	
	// Setup Time
	realTimeElapsed = 0.0;
	gameTimer = 60.0;
	
	// Setup Game Variables
	physicsHandler = [PhysicsEngine createHandler];
	
	[physicsHandler retain];
	
	float gameConstant = _GAME_CONSTANT;
	physicsHandler.gravityAcceleration = -1200.0*gameConstant;
	physicsHandler.groundElasticity = 800.0*gameConstant;
	physicsHandler.groundPlaneElevation = 5.0*gameConstant;
		
	// Setup file path string based on device
	NSString* filePathString;
	switch (GameOptions.typeOfDevice) {
		case IS_IPHONE_3_DEVICE:
			filePathString = [NSString stringWithString:@"textureFiles/lowRes/"];
			break;
		case IS_IPHONE_4_DEVICE:
			filePathString = [NSString stringWithString:@"textureFiles/retina/"];
			break;
		case IS_IPAD_DEVICE:
			filePathString = [NSString stringWithString:@"textureFiles/iPad/"];
			break;
		default:
			filePathString = [NSString stringWithString:@"textureFiles/lowRes/"];
			break;
	}	
	
	// Initiailize & Retain Character
	NSString* Player1FilePathString = [filePathString stringByAppendingString:@"char/char_blueRabbit"];
	NSString* Player2FilePathString = [filePathString stringByAppendingString:@"char/char_redRabbit"];

	Player1 = [PlayerCharacter characterWithParentNode:self file:Player1FilePathString spawnPos:CGPointMake(GameOptions.screenSize.width*3/4, GameOptions.screenSize.height/3) Player:1];
	
	[Player1 retain];	
	
	// Initiailize & Retain Opponent Character
	
	Player2 = [PlayerCharacter characterWithParentNode:self file:Player2FilePathString spawnPos:CGPointMake(GameOptions.screenSize.width*1/4, GameOptions.screenSize.height/3) Player:2];
	Player2.mass = 2;
	
	[Player2 retain];
	
	// Initialize and Retain player's off screen indicators
	NSString* Player1OffScreenIndicatorFilePathString = [filePathString stringByAppendingString:@"ingameMenu/offScreenIndicator_player1.png"];
	Player1OffScreenIndicator = [CCSprite spriteWithFile:Player1OffScreenIndicatorFilePathString];
	Player1OffScreenIndicator.position = CGPointMake(0, GameOptions.screenSize.height * 2); 
	[self addChild:Player1OffScreenIndicator z:HUDLayer tag:Player1OffScreenIndicatorID];
	
	[Player1OffScreenIndicator retain];
	
	NSString* Player2OffScreenIndicatorFilePathString = [filePathString stringByAppendingString:@"ingameMenu/offScreenIndicator_player2.png"];
	Player2OffScreenIndicator = [CCSprite spriteWithFile:Player2OffScreenIndicatorFilePathString];
	Player2OffScreenIndicator.position = CGPointMake(0, GameOptions.screenSize.height * 2); 
	[self addChild:Player2OffScreenIndicator z:HUDLayer tag:Player2OffScreenIndicatorID];
	
	[Player2OffScreenIndicator retain];
	
	// Initialize AI
	
	brain = [AIBrain createBrain];
	brain.min_X = 0;
	brain.max_X = GameOptions.screenSize.width;
	brain.min_Y = physicsHandler.groundPlaneElevation;
	brain.max_Y = GameOptions.screenSize.height*1.5;
	brain.gravityAcceleration = physicsHandler.gravityAcceleration;
	brain.groundElasticity = physicsHandler.groundElasticity;
	
	[brain retain];
	
	// Initialize POUND DOWN BUTTON
	NSString* poundDownButtonString = [filePathString stringByAppendingString:@"mainMenu/buttons/poundDownButton.png"];
	poundDownButton = [CCSprite spriteWithFile:poundDownButtonString];
	
	poundDownButton.position = CGPointMake(GameOptions.screenSize.width*8/9, GameOptions.screenSize.height*1/9);
	
	[self addChild:poundDownButton z:GUILayer tag:PoundDownButtonID];
	
	[poundDownButton retain];
		
	// Initialize Item Factory & Item CCArray
	
	myItemFactory = [[ItemFactory alloc] init];
	itemArray = [CCArray arrayWithCapacity:MAX_ITEM_CAPACITY];
	GameCounts.itemCount = 2000;
	
	[myItemFactory retain];
	[itemArray retain];
	
		
	// Setup & Retain display timer
	
	gameTimeDisplay = [CCLabelTTF labelWithString:[self timeToString:gameTimer] fontName:@"Arial" fontSize:24];
	
	gameTimeDisplay.position = CGPointMake(GameOptions.screenSize.width/2, GameOptions.screenSize.height - 40);
	
	[self addChild:gameTimeDisplay z:HUDLayer tag:GameTimeDisplayID];		
	
	// Setup & Retain display Player score
	
	Player1ScoreDisplay = [CCLabelTTF labelWithString:[NSString stringWithFormat:@"%i",0] fontName:@"Arial" fontSize:24];
	
	Player1ScoreDisplay.position = CGPointMake(GameOptions.screenSize.width*4/5, GameOptions.screenSize.height - 40*gameConstant);
	
	[self addChild:Player1ScoreDisplay z:HUDLayer tag:Player1ScoreDisplayID];		
	
	// Setup & Retain display Opponent score
	
	Player2ScoreDisplay = [CCLabelTTF labelWithString:[NSString stringWithFormat:@"%i",0] fontName:@"Arial" fontSize:24];
	
	Player2ScoreDisplay.position = CGPointMake(GameOptions.screenSize.width*4/5, GameOptions.screenSize.height - 80*gameConstant);
	
	[self addChild:Player2ScoreDisplay z:HUDLayer tag:Player2ScoreDisplayID];		
	
	
	// Setup & Retain display type
	
	NSString* typeOfDeviceString;
	switch (GameOptions.typeOfDevice) {
		case IS_IPHONE_3_DEVICE:
			typeOfDeviceString = [NSString stringWithString:@"IS IPHONE 3"];
			break;
		case IS_IPHONE_4_DEVICE:
			typeOfDeviceString = [NSString stringWithString:@"IS IPHONE 4"];
			break;
		case IS_IPAD_DEVICE:
			typeOfDeviceString = [NSString stringWithString:@"IS IPAD"];
			break;
		default:
			typeOfDeviceString = [NSString stringWithString:@"CANNOT DETECT DEVICE TYPE"];
			break;
	}
	
	
	typeOfDeviceDisplay = [CCLabelTTF labelWithString:typeOfDeviceString fontName:@"Arial" fontSize:24];
	
	typeOfDeviceDisplay.position = CGPointMake(GameOptions.screenSize.width/8, GameOptions.screenSize.height - 40);
	
	[self addChild:typeOfDeviceDisplay z:HUDLayer];		
	
	
	
	// Scene setup
	self.isAccelerometerEnabled = YES;
	[[CCTouchDispatcher sharedDispatcher] addTargetedDelegate:self priority:0 swallowsTouches:YES];
	//self.isTouchEnabled = YES;
	[self scheduleUpdate];		
}

 
//
// INIT & DEALLOC
//


- (id) init
{
	if ((self = [super init]))
	{
		CCLOG(@"%@: %@", NSStringFromSelector(_cmd), self);
		[self initialSequence];
		
	}
	return self;
}

- (void) dealloc
{
	[itemArray release];
	[myItemFactory release];
	[physicsHandler release];
	[brain release];
	[gameTimeDisplay release];
	[poundDownButton release];
	[Player1 release];
	[Player2 release];
	[super dealloc];
}

@end