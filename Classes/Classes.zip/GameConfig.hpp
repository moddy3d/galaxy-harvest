//
//  GameConfig.hpp
//  CoinCatch
//
//  Created by Richard Lei on 11-01-06.
//  Copyright __MyCompanyName__ 2011. All rights reserved.
//

#ifndef __GAME_CONFIG_H
#define __GAME_CONFIG_H

//
// Supported Autorotations:
//		None,
//		UIViewController,
//		CCDirector
//
#define kGameAutorotationNone 0
#define kGameAutorotationCCDirector 1
#define kGameAutorotationUIViewController 2

//
// Define here the type of autorotation that you want for your game
//
#define GAME_AUTOROTATION kGameAutorotationUIViewController

struct myOptions
{
	int typeOfDevice;
	CGSize screenSize;
}GameOptions;

struct myCounts
{
	int itemCount;
}GameCounts;


// Define type of device
#define IS_IPHONE_3_DEVICE 0
#define IS_IPHONE_4_DEVICE 1
#define IS_IPAD_DEVICE 2

// Game Constant for balancing between devices

#define _GAME_CONSTANT GameOptions.screenSize.height/1024.0

// velocity lim
#define _PLAYER_MAX_X_VELOCITY 1000.0*_GAME_CONSTANT
#define _PLAYER_MAX_Y_VELOCITY 1800.0*_GAME_CONSTANT

// Global Paramters
#define GAME_RUNNING_FPS 1.0/60


// Game State
typedef enum {
	GameStateRunning,
	GameStatePaused,
	GameStateFinished
}GameState;
	

//
// SCENE TARGET ID's
//
typedef enum {
	TargetSceneINVALID = 0,
	TargetSceneMenuScene,
	TargetSceneGameScene,
	TargetSceneMAX
}TargetScenes;


//
// TAG ID's
//

typedef enum {
	//GUI
	InvalidTag = 0,
	EnglishButtonID,
	ChineseButtonID,
	StartGameButtonID,
	OptionsButtonID,
	soundOnButtonID,
	soundOffButtonID,
	musicOnButtonID,
	musicOffButtonID,
	creditsButtonID,
	resetScoreButtonID,
	chineseOnButtonID,
	englishOnButtonID,
	backToMainButtonID,
	
	//INGAME
	Player1HeadID,
	Player1BodyID,
	Player2HeadID,
	Player2BodyID,
	PoundDownButtonID,
	
	//INGAME FINISHED OR PAUSED
	retryButtonID,
	
	//INGAME HUD
	GameTimeDisplayID,
	Player1ScoreDisplayID,
	Player2ScoreDisplayID,
	Player1OffScreenIndicatorID,
	Player2OffScreenIndicatorID,
}TagID;


//
// LAYER ID's
//

typedef enum {
	BackgroundLayer = 0,
	HUDLayer,
	PlayerBodyLayer,
	PlayerHeadLayer,
	ItemLayer,
	GUILayer
}ZLayers;

//
// CCLAYER ID's
//

typedef enum {
	// MENU SCREEN
	languageSelectionMenuLayerID = 0,
	mainMenuLayerID,
}CCLayerID;


//
// CHARACTER PRESETS
//
typedef enum {
	CharacterNormalExpr = 0,
	CharacterHappyExpr,
	CharacterSadExpr
}CharacterExpression;






//
// ITEM PRESETS
//
typedef enum {
	BronzeCoinItemID = 0,
	SilverCoinItemID,
	GoldCoinItemID,
	JadeCoinItemID,
	IceCoinItemID,
	RedBagItemID,
	PoopItemID,
	ExtendTimeItemID,
	NullItemID
}TypeOfItem;

// Max number of items capacity
#define MAX_ITEM_CAPACITY 1000

// Item worth

#define BRONZE_COIN_WORTH 5
#define SILVER_COIN_WORTH 15
#define GOLD_COIN_WORTH 30
#define JADE_COIN_WORTH 50
#define ICE_COIN_WORTH 5
#define RED_BAG_WORTH 5
#define POOP_WORTH -5
#define EXTEND_TIME_WORTH 0

#endif // __GAME_CONFIG_H