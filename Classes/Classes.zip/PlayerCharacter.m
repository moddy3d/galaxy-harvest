//
//  PlayerCharacter.m
//  CoinCatch
//
//  Created by Richard Lei on 11-01-06.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "PlayerCharacter.h"


@implementation PlayerCharacter

@synthesize spawnPosition, currentPosition, velocity, bounds, mass, score, playerNumber, isOffScreen, goingUp, collisionTimer, appliedForceTimer, appliedForce, headSprite, bodySprite;


- (void) updateSpritePositions
{
	// Maintains the sprite offsets with character's master current position
	headSprite.position = CGPointMake(currentPosition.x + headOffset.x, currentPosition.y + headOffset.y);
	bodySprite.position = CGPointMake(currentPosition.x + bodyOffset.x, currentPosition.y + bodyOffset.y);
}

// Factory Initialiser
+ (id) characterWithParentNode:(CCNode*)parentNode file:(NSString*)fileName spawnPos:(CGPoint)spawnPoint Player:(int)playerNo
{ 
	return [[[self alloc] initWithParentNode:parentNode file:fileName spawnPos:spawnPoint Player:playerNo] autorelease];
}

- (id) initWithParentNode:(CCNode*)parentNode file:(NSString*)fileName spawnPos:(CGPoint)spawnPoint Player:(int)playerNo
{
	if ((self = [super init]))
	{
		// Get screen size
		CGSize screenSize = [[CCDirector sharedDirector] winSize];
		
		
		// Spawn character in the middle of the screen
		spawnPosition = spawnPoint;
		
		// Set current position
		currentPosition = spawnPosition;
		
		// Set character velocity 
		velocity = CGPointMake(0, -3);
		
		// Set character bounds
		bounds = CGPointMake(screenSize.width/10, screenSize.height/7);
		
		// Set character score
		score = 0;
		
		// Set character score
		mass = 1;
		
		//
		playerNumber = playerNo;
		
		// going UP
		isOffScreen = NO;
		
		// going UP
		goingUp = NO;
		
		// set collision timer
		collisionTimer = 0;
		
		// set applied force timer
		appliedForceTimer = 0;
		appliedForce = 0;
		
		// Set initial character expression
		characterExpression = (CharacterExpression) CharacterNormalExpr;
		
		// Init CCSprite head & body for our character 
		NSString* headFileName = [fileName stringByAppendingString:@"_head_normal0.png"];
		NSString* bodyFileName = [fileName stringByAppendingString:@"_body_normal0.png"];
		
		headSprite = [CCSprite spriteWithFile:headFileName];
		bodySprite = [CCSprite spriteWithFile:bodyFileName];
		
		headSprite.anchorPoint = CGPointMake(0.5, 0);
		bodySprite.anchorPoint = CGPointMake(0.5, 0);
		headOffset = CGPointMake(0, 0);
		bodyOffset = CGPointMake(0, -screenSize.height/20);
		
		[self updateSpritePositions];

		// Attach characterSprite to parentNode
		if (playerNumber == 1) {
			[parentNode addChild:headSprite z:PlayerHeadLayer tag:Player1HeadID];
			[parentNode addChild:bodySprite z:PlayerBodyLayer tag:Player1BodyID];
		}
		else if (playerNumber == 2) {
			[parentNode addChild:headSprite z:PlayerHeadLayer tag:Player2HeadID];
			[parentNode addChild:bodySprite z:PlayerBodyLayer tag:Player2BodyID];
		}		
	}
	return self;
}

- (void) dealloc
{
	[headSprite release];
	[bodySprite release];
	[super dealloc];	
}


@end
