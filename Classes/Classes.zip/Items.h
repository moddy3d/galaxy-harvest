//
//  CoinItem.h
//  CoinCatch
//
//  Created by Richard Lei on 11-01-07.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"
#import "PlayerItem.h"


@interface BronzeCoinItem : PlayerItem {

}

@end


@interface SilverCoinItem : PlayerItem {
	
}

@end

@interface GoldCoinItem : PlayerItem {
	
}

@end

@interface JadeCoinItem : PlayerItem {
	
}

@end

@interface IceCoinItem : PlayerItem {
	
}

@end

@interface RedBagItem : PlayerItem {
	
}

@end

@interface PoopItem : PlayerItem {
	
}

@end

@interface ExtendTimeItem : PlayerItem {
	
}

@end