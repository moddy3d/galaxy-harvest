//
//  PlayerCharacter.h
//  CoinCatch
//
//  Created by Richard Lei on 11-01-06.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"
#import "GameConfig.hpp"

//
//	Character Wrapper Class
//	


@interface PlayerCharacter : NSObject {
	CGPoint spawnPosition;
	CGPoint currentPosition;
	CGPoint velocity;
	CGPoint bounds;
	CGPoint headOffset;
	CGPoint bodyOffset;
	
	float mass;
	int score;
	int playerNumber;
	
	
	BOOL isOffScreen;
	BOOL goingUp;
	float collisionTimer;
	float appliedForceTimer;
	float appliedForce;
	
	CharacterExpression characterExpression;
	CCSprite* headSprite;
	CCSprite* bodySprite;
}

@property CGPoint spawnPosition;
@property CGPoint currentPosition;
@property CGPoint velocity;
@property CGPoint bounds;
@property float mass;
@property int score;
@property (readonly) int playerNumber;
@property BOOL isOffScreen;
@property BOOL goingUp;
@property float collisionTimer;
@property float appliedForceTimer;
@property float appliedForce;
@property (nonatomic,retain) CCSprite* headSprite;
@property (nonatomic,retain) CCSprite* bodySprite;

- (void) updateSpritePositions;
+ (id) characterWithParentNode:(CCNode*)parentNode file:(NSString*)fileName spawnPos:(CGPoint)spawnPoint Player:(int)playerNo;
- (id) initWithParentNode:(CCNode*)parentNode file:(NSString*)fileName spawnPos:(CGPoint)spawnPoint Player:(int)playerNo;

@end
