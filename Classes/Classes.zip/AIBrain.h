//
//  AIBrain.h
//  CoinCatch
//
//  Created by Richard Lei on 11-01-12.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"
#import "GameConfig.hpp"
#import "PlayerCharacter.h"
#import "Items.h"
#import "PhysicsEngine.h"

@interface AIBrain : NSObject {
	
	int min_X;
	int max_X;
	int min_Y;
	int max_Y;
	
	float gravityAcceleration;
	float groundElasticity;

	float thinkReloadTimer;
	float thinkRate;
	
	float poundDownReloadTimer;
	float poundDownRate;
	
	float directionalChangeRate;
}

@property int min_X;
@property int max_X;
@property int min_Y;
@property int max_Y;

@property float gravityAcceleration;
@property float groundElasticity;
@property float thinkRate;
@property float directionalChangeRate;


+ (id) createBrain;
- (void) feedSelf:(PlayerCharacter*)selfChar feedEnemy:(PlayerCharacter*)enemyChar feedItems:(CCArray*)items feedTime:(ccTime)delta motionHandler:(PhysicsEngine*)physicsHandler;

@end
