//
//  AIBrain.m
//  CoinCatch
//
//  Created by Richard Lei on 11-01-12.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "AIBrain.h"



@implementation AIBrain

@synthesize min_X, max_X, min_Y, max_Y, gravityAcceleration, groundElasticity, thinkRate, directionalChangeRate;

// Factory Method
+ (id) createBrain
{
	return [[[self alloc] init] autorelease];
}


// Calculators
- (void) canGetItem:(PlayerItem*)item
{
	
}


// Searchers
- (PlayerItem*) smartItemSearch:(CCArray*)itemArray toChar:(PlayerCharacter*)selfChar
{	
	if ([itemArray count] > 0)
	{
		NSAssert([[itemArray objectAtIndex:0] isKindOfClass:[PlayerItem class]],@"IS NOT AN ITEM");
		NSAssert([selfChar isKindOfClass:[PlayerCharacter class]],@"IS NOT AN CHARACTER");
		float closestDistance = GameOptions.screenSize.height*2;
		int closestItemIndex = -1;
		float highestItemWorth = 0;
		int highestItemWorthIndex = -1;
		for (int count = 0; count < [itemArray count]; count++) {
			PlayerItem* item = [itemArray objectAtIndex:count];
			if (item.itemType != PoopItemID) {
				CCSprite* itemSprite = item.itemSprite;
				if (item.worth > highestItemWorth) {
					highestItemWorth = item.worth;
					highestItemWorthIndex = count;
				}
				float currentDistance = ccpDistance(itemSprite.position, selfChar.currentPosition);
				if (currentDistance < closestDistance) {
					closestDistance = currentDistance;
					closestItemIndex = count;
				}
			}
		}
		if (closestItemIndex != -1) {
			if (highestItemWorth > SILVER_COIN_WORTH) {
				return [itemArray objectAtIndex:highestItemWorthIndex];
			}
			else {
				return [itemArray objectAtIndex:closestItemIndex];
			}
		}
		else {
			return nil;
		}
	}
	else {
		return nil;
	}
}

- (PlayerItem*) findNearestPoop:(CCArray*)itemArray toChar:(PlayerCharacter*)selfChar
{	
	if ([itemArray count] > 0)
	{
		NSAssert([[itemArray objectAtIndex:0] isKindOfClass:[PlayerItem class]],@"IS NOT AN ITEM");
		NSAssert([selfChar isKindOfClass:[PlayerCharacter class]],@"IS NOT AN CHARACTER");
		float closestDistanceToPoop = GameOptions.screenSize.height*2;
		int closestPoopIndex = -1;
		for (int count = 0; count < [itemArray count]; count++) {
			PlayerItem* item = [itemArray objectAtIndex:count];
			if (item.itemType == PoopItemID) {
				CCSprite* itemSprite = item.itemSprite;
				float currentDistance = ccpDistance(itemSprite.position, selfChar.currentPosition);
				if (currentDistance < closestDistanceToPoop) {
					closestDistanceToPoop = currentDistance;
					closestPoopIndex = count;
				}
			}
		}
		if (closestPoopIndex != -1) {
			return [itemArray objectAtIndex:closestPoopIndex];
		}
		else {
			return nil;
		}

	}
	else {
		return nil;
	}
}



// Actors

- (void) stomp:(PlayerCharacter*)selfChar target:(PlayerCharacter*)enemyChar motionHandler:(PhysicsEngine*)physicsHandler
{
	if ((selfChar.currentPosition.y > enemyChar.currentPosition.y) && (fabs(selfChar.currentPosition.x - enemyChar.currentPosition.x) < (selfChar.bounds.x + enemyChar.bounds.x/2))) {
		selfChar.velocity = CGPointMake(selfChar.velocity.x/4 + enemyChar.velocity.x, selfChar.velocity.y);
		if (fabs(selfChar.velocity.x - enemyChar.velocity.x) < 200*_GAME_CONSTANT) {
			[physicsHandler poundDownWithPlayer:selfChar];
		}
	}
}

- (void) bump:(PlayerCharacter*)selfChar target:(PlayerCharacter*)enemyChar motionHandler:(PhysicsEngine*)physicsHandler
{
	if (ccpDistance(selfChar.currentPosition, enemyChar.currentPosition) < selfChar.bounds.x*2) {
		selfChar.velocity = CGPointMake(selfChar.velocity.x - enemyChar.velocity.x, selfChar.velocity.y);
	}
}

- (void) avoidBeingStomped:(PlayerCharacter*)selfChar by:(PlayerCharacter*)enemyChar motionHandler:(PhysicsEngine*)physicsHandler
{
	// conditional statement basically checks if enemy character is hovering above self character
	if ((selfChar.currentPosition.y < enemyChar.currentPosition.y) && (fabs(selfChar.currentPosition.x - enemyChar.currentPosition.x) < (selfChar.bounds.x + enemyChar.bounds.x/2))) {
		float velocityX = selfChar.velocity.x;
		
		if (fabs(enemyChar.velocity.x) > 400*_GAME_CONSTANT) {
			velocityX += -enemyChar.velocity.x * directionalChangeRate * _GAME_CONSTANT;
		}
		else {
			if (enemyChar.velocity.x > 0) {
				velocityX += 600*_GAME_CONSTANT;
			}
			else {
				velocityX += -600*_GAME_CONSTANT;
			}			
		}
		
		selfChar.velocity = CGPointMake(velocityX, selfChar.velocity.y);
	}
}

- (void) avoidPoop:(PlayerCharacter*)selfChar item:(PlayerItem*)poop
{
	if (poop != nil) {
		CCLOG(@"FOUND POOP");
		CCSprite* poopSprite = poop.itemSprite;
		float distanceBetween = ccpDistance(selfChar.currentPosition, poopSprite.position);
		if (distanceBetween < 300 * _GAME_CONSTANT) {
			CCLOG(@"POOP IS CLOSE");
			if (distanceBetween == 0) {
				distanceBetween += 0.1;
			}
			distanceBetween /= 10*_GAME_CONSTANT;
			selfChar.velocity = CGPointMake(selfChar.velocity.x * -500 * (poopSprite.position.x - selfChar.currentPosition.x), selfChar.velocity.y);

		}
	}
}

- (void) homeInOnItem:(PlayerItem*)item moveChar:(PlayerCharacter*)selfChar opponent:(PlayerCharacter*)enemyChar feedItems:(CCArray*)itemArray motionHandler:(PhysicsEngine*)physicsHandler
{
	if (item != nil) {
		NSAssert([item isKindOfClass:[PlayerItem class]],@"IS NOT AN ITEM");
		NSAssert([selfChar isKindOfClass:[PlayerCharacter class]],@"IS NOT AN CHARACTER");
		
		// Stomp opponent code
		if (item.worth < GOLD_COIN_WORTH) {
			[self stomp:selfChar target:enemyChar motionHandler:physicsHandler];
		}
		
		
		CCSprite* itemSprite = item.itemSprite;
		CGPoint itemPosition = itemSprite.position;
		
		CGPoint charPosition = selfChar.currentPosition;
		
		float differenceX = itemPosition.x - charPosition.x;
		
		
		// acceleration towards target is the difference of distance from object subtracted by a random range 0-20 then added with the current applied force
		
		float accelerationTowardsTarget = differenceX * directionalChangeRate *_GAME_CONSTANT + selfChar.appliedForce;
		
		float addVelocity = accelerationTowardsTarget * GAME_RUNNING_FPS;
		
		// new velocity is the old velocity plus the added velocity minus a factor that slows it down
		
		float newVelocityX = selfChar.velocity.x + addVelocity;
		
		if (fabs(differenceX) < 50 * _GAME_CONSTANT) {
			newVelocityX /= 2;
		}
		
		selfChar.velocity = CGPointMake(newVelocityX, selfChar.velocity.y);
		/*
		if (fabs(differenceX) < 50 * _GAME_CONSTANT) {
			[self bump:selfChar target:enemyChar motionHandler:physicsHandler];
		}
		 */
		
		if (poundDownReloadTimer == 0) {
			float differenceY = itemPosition.y - charPosition.y;
			if (fabs(differenceY) > 70*_GAME_CONSTANT && selfChar.velocity.y < 0)
			{
				[physicsHandler poundDownWithPlayer:selfChar];
			}
			poundDownReloadTimer = poundDownRate;
		}
		
		if (item.worth < JADE_COIN_WORTH) {
			// Avoid being stomped on code
			[self avoidBeingStomped:selfChar by:enemyChar motionHandler:physicsHandler];
		}
		// Avoid poop code
	//	[self avoidPoop:selfChar item:[self findNearestPoop:itemArray toChar:selfChar]];
	}
}







// Planners
- (void) makePrioritiesForSelf:(PlayerCharacter*)selfChar feedEnemy:(PlayerCharacter*)enemyChar feedItems:(CCArray*)itemArray
{
	
}

// Main world feed
- (void) feedSelf:(PlayerCharacter*)selfChar feedEnemy:(PlayerCharacter*)enemyChar feedItems:(CCArray*)itemArray feedTime:(ccTime)delta motionHandler:(PhysicsEngine*)physicsHandler
{
	// tick pound down timer
	poundDownReloadTimer -= delta;
	if (poundDownReloadTimer < 0)
		poundDownReloadTimer = 0;
	
	if (thinkReloadTimer == 0) {
		NSAssert([selfChar isKindOfClass:[PlayerCharacter class]],@"IS NOT AN CHARACTER");
		
		// AI think sequence
		[self homeInOnItem:[self smartItemSearch:itemArray toChar:selfChar] moveChar:selfChar opponent:enemyChar feedItems:itemArray motionHandler:physicsHandler];
		
		
		thinkReloadTimer = thinkRate;
	}
	else {
		thinkReloadTimer -= delta;
		if (thinkReloadTimer < 0)
			thinkReloadTimer = 0;
		}
}


// Init & Dealloc
- (id) init
{
	if ((self = [super init]))
	{
		thinkRate = 0.1;
		thinkReloadTimer = 0;
		
		poundDownRate = 1.0;
		poundDownReloadTimer = 0;
		
		directionalChangeRate = 50.0;
	}
	return self;
}

- (void) dealloc
{
	[super dealloc];	
}
@end
