//
//  UserMenuButton.h
//  CoinCatch
//
//  Created by Richard Lei on 11-01-06.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//


#import <Foundation/Foundation.h>
#import "cocos2d.h"
#import "GameConfig.hpp"




@interface UserMenuButton : NSObject <CCTargetedTouchDelegate> 
{
	BOOL hasLoadingScreen;
	TargetScenes targetedScene;
	CCSprite* buttonSprite;
}

@property (nonatomic,retain) CCSprite* buttonSprite;

+ (id) buttonWithParentNode:(CCNode*)parentNode file:(NSString*)name tag:(TagID)tagID sceneToTarget:(TargetScenes)scene hasLoading:(BOOL)loading;
- (id) initWithParentNode:(CCNode*)parentNode file:(NSString*)name tag:(TagID)tagID sceneToTarget:(TargetScenes)scene hasLoading:(BOOL)loading;

@end
