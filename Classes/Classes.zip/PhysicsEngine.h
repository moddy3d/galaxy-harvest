//
//  PhysicsEngine.h
//  CoinCatch
//
//  Created by Richard Lei on 11-01-14.
//  Copyright 2011 Creative Inventory Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"
#import "GameConfig.hpp"
#import "PlayerCharacter.h"
#import "Items.h"


@interface PhysicsEngine : NSObject {
	// Game Variables
	float gravityAcceleration;
	float groundElasticity;
	float groundPlaneElevation;
}

// Game Variables
@property float gravityAcceleration;
@property float groundElasticity;
@property float groundPlaneElevation;


// Factory method
+ (id) createHandler;

// Collision Handlers
- (void) checkPlayerToPlayerCollision:(ccTime)delta playerOne:(PlayerCharacter*)Player1 playerTwo:(PlayerCharacter*)Player2 gameState:(GameState)stateOfGame items:(CCArray*)itemArray gameNode:(CCLayer*)parentNode;
- (void) checkPlayerGroundCollision:(PlayerCharacter*)Player gameState:(GameState)stateOfGame;
- (void) checkItemGroundCollision:(CCArray*)itemArray gameState:(GameState)stateOfGame gameNode:(CCLayer*)parentNode;
- (void) checkItemCollision:(PlayerCharacter*)Player items:(CCArray*)itemArray gameState:(GameState)stateOfGame gameNode:(CCLayer*)parentNode;

// Motion Handlers
- (void) moveCharacter:(ccTime)delta whatPlayer:(PlayerCharacter*)player gameState:(GameState)stateOfGame;
- (void) moveItems:(ccTime)delta items:(CCArray*)itemArray gameState:(GameState)stateOfGame;
- (void) poundDownWithPlayer:(PlayerCharacter*)player;
- (void) accelerateXWithCharacter:(PlayerCharacter*)player accelerometerX:(float)accelerationX decelerate:(float)deceleration accelerometerSensitivity:(float)sensitivity;
@end
