//
//  PhysicsEngine.m
//  CoinCatch
//
//  Created by Richard Lei on 11-01-14.
//  Copyright 2011 Creative Inventory Ltd. All rights reserved.
//

#import "PhysicsEngine.h"


@implementation PhysicsEngine

@synthesize gravityAcceleration, groundElasticity, groundPlaneElevation;

// 
// INTERACTION HANDLERS
//
- (void) accelerateXWithCharacter:(PlayerCharacter*)player accelerometerX:(float)accelerationX decelerate:(float)deceleration accelerometerSensitivity:(float)sensitivity
{
	CGPoint characterVelocity = player.velocity;

	characterVelocity.x = characterVelocity.x * deceleration + GAME_RUNNING_FPS * player.appliedForce + accelerationX * sensitivity;

	player.velocity = characterVelocity;	
}



//
// MOTION HANDLERS
//

- (void) moveCharacter:(ccTime)delta whatPlayer:(PlayerCharacter*)Player gameState:(GameState)stateOfGame
{
	if (stateOfGame == GameStateRunning) {		
		
		if (Player.velocity.y > 0) {
			Player.goingUp = YES;
		}
		else {
			Player.goingUp = NO;
		}
				
		// Change velocity based on acceleration		

		CGPoint characterVelocity = Player.velocity;
		
		// Subtract applied force timer  ... but applied force is calculated in the interaction handler to reduce glitching
		if (Player.appliedForceTimer > 0) {
			Player.appliedForceTimer -= delta;
			Player.appliedForce = Player.appliedForce*3/4;
			if (Player.appliedForceTimer < 0 || Player.appliedForceTimer == 0) {
				Player.appliedForceTimer = 0;
				Player.appliedForce = 0;
			}
		}
				
		characterVelocity.y += (gravityAcceleration * delta);
		
		// Limit player char velocity
		if (characterVelocity.x > _PLAYER_MAX_X_VELOCITY)
			characterVelocity.x = _PLAYER_MAX_X_VELOCITY;
		
		if (characterVelocity.x < -_PLAYER_MAX_X_VELOCITY)
			characterVelocity.x = -_PLAYER_MAX_X_VELOCITY;
		
		
		if (characterVelocity.y > _PLAYER_MAX_Y_VELOCITY)
			characterVelocity.y = _PLAYER_MAX_Y_VELOCITY;
		
		if (characterVelocity.y < -_PLAYER_MAX_Y_VELOCITY)
			characterVelocity.y = -_PLAYER_MAX_Y_VELOCITY;
		
		Player.velocity = characterVelocity;
		
		
		// Change position based on velocity	
		CGPoint playerPos = Player.currentPosition;
		playerPos.x += Player.velocity.x * delta;
		playerPos.y += Player.velocity.y * delta;
		
		//check if player OOB
		float playerImageWidth = Player.bounds.x;
		
		if(playerPos.x > (GameOptions.screenSize.width + (playerImageWidth/2)))
		{
			playerPos.x = -playerImageWidth/2;
		}
		
		if(playerPos.x < -playerImageWidth/2)
		{
			playerPos.x = (GameOptions.screenSize.width + (playerImageWidth/2));
		}
		
		//set sprite final position
		
		Player.currentPosition = playerPos;
		
		// If Player's Y Position is greater than the screen's height plus the Player's character's height * 1/2 then he is offscreen
		if (Player.currentPosition.y > (GameOptions.screenSize.height + Player.bounds.y/2)) {
			Player.isOffScreen = YES;
		}
		else {
			Player.isOffScreen = NO;
		}
		
		[Player updateSpritePositions];
	}
}

- (void) moveItems:(ccTime)delta items:(CCArray*)itemArray gameState:(GameState)stateOfGame
{
	if (stateOfGame == GameStateRunning) {
		for (int count = 0; count < [itemArray count]; count++) {
			NSAssert([[itemArray objectAtIndex:count] isKindOfClass:[PlayerItem class]],@"IS NOT AN ITEM");
			PlayerItem* item = [itemArray objectAtIndex:count];
			
			// decrement edible timer
			if (item.edibleTimer != 0) {
				item.edibleTimer -= delta;
				if (item.edibleTimer < 0)
					item.edibleTimer = 0;
			}
			
			// Get window size		
			
			// Change velocity based on acceleration
			CGPoint itemVelocity = item.velocity;
			if(item.affectedByForces == YES) {
				itemVelocity.y += (gravityAcceleration * delta);
				item.velocity = itemVelocity;
			}
			
			CCSprite* itemSprite = item.itemSprite;
			// Change position based on velocity	
			CGPoint itemPos = itemSprite.position;
			itemPos.x += item.velocity.x * delta;
			itemPos.y += item.velocity.y * delta;
			
			itemSprite.position = itemPos;
		}
	}
}

- (void) poundDownWithPlayer:(PlayerCharacter *)player
{
	player.velocity = CGPointMake(player.velocity.x * 2, player.velocity.y-600*_GAME_CONSTANT);
	if (player.velocity.y > -200*_GAME_CONSTANT)
		player.velocity = CGPointMake(player.velocity.x, -200*_GAME_CONSTANT);
}


//
// REACTORS
//

- (void) playerSteppedOn:(PlayerCharacter*)steppedOnPlayer items:(CCArray*)itemArray gameNode:(CCLayer*)parentNode
{
	CGPoint playerPosition = steppedOnPlayer.currentPosition;
	
	CGPoint coin1InitPosition = CGPointMake(playerPosition.x - 20*_GAME_CONSTANT, playerPosition.y);
	CGPoint coin1InitVelocity = CGPointMake(-200*_GAME_CONSTANT, 500*_GAME_CONSTANT);
	BronzeCoinItem* coin1 = [BronzeCoinItem itemWithParentNode:parentNode initPosition:coin1InitPosition initVelocity:coin1InitVelocity isAffectedByForces:YES edibleInTime:0.5];
	
	CGPoint coin2InitPosition = CGPointMake(playerPosition.x + 20*_GAME_CONSTANT, playerPosition.y);
	CGPoint coin2InitVelocity = CGPointMake(200*_GAME_CONSTANT, 500*_GAME_CONSTANT);
	BronzeCoinItem* coin2 = [BronzeCoinItem itemWithParentNode:parentNode initPosition:coin2InitPosition initVelocity:coin2InitVelocity isAffectedByForces:YES edibleInTime:0.5];
	
	CGPoint coin3InitPosition = playerPosition;
	CGPoint coin3InitVelocity = CGPointMake(CCRANDOM_0_1()*30*_GAME_CONSTANT - 15*_GAME_CONSTANT, 900*_GAME_CONSTANT);
	BronzeCoinItem* coin3 = [BronzeCoinItem itemWithParentNode:parentNode initPosition:coin3InitPosition initVelocity:coin3InitVelocity isAffectedByForces:YES edibleInTime:0.5];
	
	steppedOnPlayer.score -= 15;
	[itemArray addObject:coin1];
	[itemArray addObject:coin2];
	[itemArray addObject:coin3];
}




//
// COLLISION HANDLERS
//

- (void) checkPlayerToPlayerCollision:(ccTime)delta playerOne:(PlayerCharacter*)Player1 playerTwo:(PlayerCharacter*)Player2 gameState:(GameState)stateOfGame items:(CCArray*)itemArray gameNode:(CCLayer*)parentNode
{
	if (stateOfGame == GameStateRunning) {
		if (Player1.collisionTimer == 0 && Player2.collisionTimer == 0) {
			if (ccpDistance(Player1.currentPosition, Player2.currentPosition) < (Player1.bounds.y/2 + Player2.bounds.y/2)) {
				float gameConstant = _GAME_CONSTANT;
				
				//PREDICT FUTURE COLLISION
				float X1 = Player1.currentPosition.x + (Player1.velocity.x * delta*3/4);
				float Y1 = Player1.currentPosition.y + (Player1.velocity.y * delta*3/4);
				
				float BX1 = Player1.bounds.x;
				float BY1 = Player1.bounds.y;
				
				//PREDICT FUTURE COLLISION
				float X2 = Player2.currentPosition.x + (Player2.velocity.x * delta*3/4);
				float Y2 = Player2.currentPosition.y + (Player2.velocity.y * delta*3/4);
				
				float BX2 = Player2.bounds.x;
				float BY2 = Player2.bounds.y;		
				
				CGPoint initialPlayer1Velocity = Player1.velocity;
				CGPoint initialPlayer2Velocity = Player2.velocity;
				
				// player jump on opponent head
				if ((X1 < (X2 + BX2/2 + BX1/2)) &&
					(X1 > (X2 - BX2/2 - BX1/2)) &&
					((Y1 - BY1/2) > (Y2 + BY2/2 - 61*gameConstant)) &&
					((Y1 - BY1/2) < (Y2 + BY2/2)))
				{
					//
					Player1.velocity = CGPointMake(Player1.velocity.x, Player1.velocity.y + 1000*gameConstant);
					// Min bounce off velocity
					if (Player1.velocity.y < 600*gameConstant)
						Player1.velocity = CGPointMake(Player1.velocity.x, 600*gameConstant);
					// Max bounce off velocity
					if (Player1.velocity.y > 1000*gameConstant)
						Player1.velocity = CGPointMake(Player1.velocity.x, 1000*gameConstant);
					
					Player2.velocity = CGPointMake(Player2.velocity.x, Player2.velocity.y -1000*gameConstant);
					if (Player2.velocity.y > -500*gameConstant)
						Player2.velocity = CGPointMake(Player2.velocity.x, -500*gameConstant);
					if (Player2.velocity.y < -1000*gameConstant)
						Player2.velocity = CGPointMake(Player2.velocity.x, -1000*gameConstant);
					
					if (Player2.score >= 15) {
						[self playerSteppedOn:Player2 items:itemArray gameNode:parentNode];
					}
					Player1.collisionTimer = 0.1;
					Player2.collisionTimer = 0.1;
				}
				// opponent jump on player head
				else if ((X1 < (X2 + BX2/2 + BX1/2)) &&
						 (X1 > (X2 - BX2/2 - BX1/2)) &&
						 ((Y2 - BY2/2) > (Y1 + BY1/2 - 61*gameConstant)) &&
						 ((Y2 - BY2/2) < (Y1 + BY1/2)))
				{
					Player2.velocity = CGPointMake(Player2.velocity.x, 1000*gameConstant);
					
					if (Player2.velocity.y < 600*gameConstant)
						Player2.velocity = CGPointMake(Player2.velocity.x, 600*gameConstant);
					if (Player2.velocity.y > 1000*gameConstant)
						Player2.velocity = CGPointMake(Player1.velocity.x, 1000*gameConstant);
					
					Player1.velocity = CGPointMake(Player1.velocity.x, -500*gameConstant);
					
					if (Player1.velocity.y > -500*gameConstant)
						Player1.velocity = CGPointMake(Player1.velocity.x, -500*gameConstant);
					if (Player1.velocity.y < -1000*gameConstant)
						Player1.velocity = CGPointMake(Player2.velocity.x, -1000*gameConstant);
					
					
					if (Player1.score >= 15) {
						[self playerSteppedOn:Player1 items:itemArray gameNode:parentNode];
					}

					Player2.collisionTimer = 0.1;
					Player1.collisionTimer = 0.1;
				}
				
				// collide eachother
				
				else if ((Y1 < (Y2 + BY2/2 + BY1/2)) &&
						 (Y1 > (Y2 - BY2/2 - BY1/2)) &&
						 ((X1 - BX1/2) > (X2 + BX2/2 - 100*gameConstant)) &&
						 ((X1 - BX1/2) < (X2 + BX2/2)))
				{
					Player1.velocity = CGPointMake(((initialPlayer2Velocity.x - initialPlayer1Velocity.x)*Player2.mass*2 + 
													initialPlayer1Velocity.x*Player1.mass + initialPlayer2Velocity.x*Player2.mass)/
												   (Player1.mass + Player2.mass), Player1.velocity.y);
					Player2.velocity = CGPointMake(((initialPlayer1Velocity.x - initialPlayer2Velocity.x)*Player1.mass*2 + 
													initialPlayer1Velocity.x*Player1.mass + initialPlayer2Velocity.x*Player2.mass)/
												   (Player1.mass + Player2.mass), Player2.velocity.y);
					
					// Bumping into eachother sets off applied force for 'dizziness' effect
					Player1.appliedForceTimer = 1;
					Player2.appliedForceTimer = 1;
					
					Player1.appliedForce = Player1.velocity.x * 80 * gameConstant * Player2.mass;
					Player2.appliedForce = Player2.velocity.x * 80 * gameConstant * Player1.mass;
					
					// Set off collision timer to allow time for reaction of collisions
					Player1.collisionTimer = 0.02;
					Player2.collisionTimer = 0.02;
				}
				
				else if ((Y1 < (Y2 + BY2/2 + BY1/2)) &&
						 (Y1 > (Y2 - BY2/2 - BY1/2)) &&
						 ((X1 + BX1/2) > (X2 - BX2/2)) &&
						 ((X1 + BX1/2) < (X2 - BX2/2 + 100*gameConstant)))
				{
					//((Player2.velocity.x - Player1.velocity.x)*2/3 + Player1.velocity.x + Player2.velocity.x)/2
					Player1.velocity = CGPointMake(((initialPlayer2Velocity.x - initialPlayer1Velocity.x)*Player2.mass*2 + 
													initialPlayer1Velocity.x*Player1.mass + initialPlayer2Velocity.x*Player2.mass)/
												   (Player1.mass + Player2.mass), Player1.velocity.y);
					Player2.velocity = CGPointMake(((initialPlayer1Velocity.x - initialPlayer2Velocity.x)*Player1.mass*2 + 
													initialPlayer1Velocity.x*Player1.mass + initialPlayer2Velocity.x*Player2.mass)/
												   (Player1.mass + Player2.mass), Player2.velocity.y);
					
					// Bumping into eachother sets off applied force for 'dizziness' effect
					Player1.appliedForceTimer = 1;
					Player2.appliedForceTimer = 1;
					
					Player1.appliedForce = Player1.velocity.x * 80 * gameConstant * Player2.mass;
					Player2.appliedForce = Player2.velocity.x * 80 * gameConstant * Player1.mass;
					
					// Set off collision timer to allow time for reaction of collisions
					Player1.collisionTimer = 0.02;
					Player2.collisionTimer = 0.02;
				}
			}
			
		}
		else if (Player1.collisionTimer != 0 || Player2.collisionTimer != 0){
			Player1.collisionTimer -= delta;
			Player2.collisionTimer -= delta;
			if (Player1.collisionTimer < 0) {
				Player1.collisionTimer = 0;
			}
			if (Player2.collisionTimer < 0) {
				Player2.collisionTimer = 0;
			}
		}
	}
}



- (void) checkPlayerGroundCollision:(PlayerCharacter*)Player gameState:(GameState)stateOfGame
{
	if (stateOfGame == GameStateRunning) {
		// Get window size
		
		//
		// Player ground collision
		//
		float playerImageHeight = Player.bounds.y;
		float playerCollisionRadius = playerImageHeight * 0.45f;
		
		float playerHeight = Player.currentPosition.y;
		float distanceFromGround = playerHeight - groundPlaneElevation;
		
		if (distanceFromGround < playerCollisionRadius && !Player.goingUp) {
			if (-Player.velocity.y < groundElasticity) {
				Player.velocity = CGPointMake(Player.velocity.x, groundElasticity);
			}
			else {
				Player.velocity = CGPointMake(Player.velocity.x, -Player.velocity.y*4/5);
			}
		}
	}
}

- (void) checkItemGroundCollision:(CCArray*)itemArray gameState:(GameState)stateOfGame gameNode:(CCLayer*)parentNode
{
	if (stateOfGame == GameStateRunning) {
		for (int count = 0; count < [itemArray count]; count++) {
			NSAssert([[itemArray objectAtIndex:count] isKindOfClass:[PlayerItem class]],@"IS NOT AN ITEM");
			PlayerItem* item = [itemArray objectAtIndex:count];
			
			CCSprite* itemSprite = item.itemSprite;
			float itemImageHeight = [itemSprite texture].contentSize.height;
			float itemCollisionRadius = itemImageHeight * 0.45f;
			
			CGPoint itemPosition = itemSprite.position;
			float itemHeight = itemPosition.y;
			float distanceFromGround = itemHeight - (groundPlaneElevation);
			
			if (distanceFromGround < itemCollisionRadius) {
				[parentNode removeChildByTag:item.tagNo cleanup:YES];
				[itemArray removeObject:item];
			}
			
		}
	}
}

- (void) checkItemCollision:(PlayerCharacter*)Player items:(CCArray*)itemArray gameState:(GameState)stateOfGame gameNode:(CCLayer*)parentNode
{
	if (stateOfGame == GameStateRunning) {
		float playerImageHeight = Player.bounds.y;
		float playerCollisionRadius = playerImageHeight * 0.45f;
		
		CGPoint playerPosition = Player.currentPosition;
		
		for (int count = 0; count < [itemArray count]; count++) {
			NSAssert([[itemArray objectAtIndex:count] isKindOfClass:[PlayerItem class]],@"IS NOT AN ITEM");
			PlayerItem* item = [itemArray objectAtIndex:count];
			if (item.edibleTimer == 0) {
				CCSprite* itemSprite = item.itemSprite;
				float itemImageHeight = [itemSprite texture].contentSize.height;
				float itemCollisionRadius = itemImageHeight * 0.45f;
				
				float maxCollisionDistance = itemCollisionRadius + playerCollisionRadius;
				
				CGPoint itemPosition = itemSprite.position;
				
				float distanceBetween = ccpDistance(playerPosition, itemPosition);
				
				if (distanceBetween < maxCollisionDistance) {
					
					Player.score += item.worth;
					
					[parentNode removeChildByTag:item.tagNo cleanup:YES];
					[itemArray removeObject:item];
				}
			}
		}
	}
	
}




//
// INIT & DEALLOC
//

+ (id) createHandler
{
	return [[self alloc] init];
}



- (id) init
{
	if ((self = [super init]))
	{
				
	}
	return self;
}

- (void) dealloc
{
	[super dealloc];
}


@end
