//
//  CoinItem.m
//  CoinCatch
//
//  Created by Richard Lei on 11-01-07.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//


#import "Items.h"

//
// BRONZE COIN 
//
@implementation BronzeCoinItem

- (NSString*) returnItemFileName:(NSString*)folderString
{
	return [folderString stringByAppendingString:@"item_bronzeCoin0.png"];
}


- (void) setItemType
{
	itemType = BronzeCoinItemID;
}

- (void) setItemWorth
{
	worth = BRONZE_COIN_WORTH;
}

- (void) dealloc
{
	[super dealloc];
}

@end


//
// SILVER COIN 
//
@implementation SilverCoinItem

- (NSString*) returnItemFileName:(NSString*)folderString
{
	return [folderString stringByAppendingString:@"item_silverCoin0.png"];
}

- (void) setItemType
{
	itemType = SilverCoinItemID;
}

- (void) setItemWorth
{
	worth = SILVER_COIN_WORTH;
}

- (void) dealloc
{
	[super dealloc];
}

@end


//
// GOLD COIN 
//
@implementation GoldCoinItem

- (NSString*) returnItemFileName:(NSString*)folderString
{
	return [folderString stringByAppendingString:@"item_goldCoin0.png"];
}


- (void) setItemType
{
	itemType = GoldCoinItemID;
}

- (void) setItemWorth
{
	worth = GOLD_COIN_WORTH;
}

- (void) dealloc
{
	[super dealloc];
}

@end



//
// JADE COIN 
//
@implementation JadeCoinItem

- (NSString*) returnItemFileName:(NSString*)folderString
{
	return [folderString stringByAppendingString:@"item_jadeCoin0.png"];
}


- (void) setItemType
{
	itemType = JadeCoinItemID;
}

- (void) setItemWorth
{
	worth =  JADE_COIN_WORTH;
}

- (void) dealloc
{
	[super dealloc];
}

@end

//
// ICE COIN 
//
@implementation IceCoinItem

- (NSString*) returnItemFileName:(NSString*)folderString
{
	return [folderString stringByAppendingString:@"item_iceCoin0.png"];
}


- (void) setItemType
{
	itemType = IceCoinItemID;
}

- (void) setItemWorth
{
	worth =  ICE_COIN_WORTH;
}

- (void) dealloc
{
	[super dealloc];
}

@end

//
// REDBAG 
//
@implementation RedBagItem

- (NSString*) returnItemFileName:(NSString*)folderString
{
	return [folderString stringByAppendingString:@"item_redBag0.png"];
}

- (void) setItemType
{
	itemType = RedBagItemID;
}

- (void) setItemWorth
{
	worth =  RED_BAG_WORTH;
}


- (void) dealloc
{
	[super dealloc];
}

@end



//
// POOP
//
@implementation PoopItem

- (NSString*) returnItemFileName:(NSString*)folderString
{
	return [folderString stringByAppendingString:@"item_poop0.png"];
}

- (void) setItemType
{
	itemType = PoopItemID;
}

- (void) setItemWorth
{
	worth =  POOP_WORTH;
}

- (void) dealloc
{
	[super dealloc];
}

@end

//
// Poop
//
@implementation ExtendTimeItem

- (NSString*) returnItemFileName:(NSString*)folderString
{
	return [folderString stringByAppendingString:@"item_extendTime0.png"];
}

- (void) setItemType
{
	itemType = ExtendTimeItemID;
}

- (void) setItemWorth
{
	worth =  EXTEND_TIME_WORTH;
}


- (void) dealloc
{
	[super dealloc];
}

@end