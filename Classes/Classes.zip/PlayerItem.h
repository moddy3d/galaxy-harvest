//
//  PlayerItem.h
//  CoinCatch
//
//  Created by Richard Lei on 11-01-07.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"
#import "GameConfig.hpp"



typedef enum {
	SpawnItemFromTop = 0,
	SpawnItemFromSide
}WhereToSpawnItem;


@interface PlayerItem : NSObject 
{
	TypeOfItem itemType;
	int worth;
	int tagNo;
	float edibleTimer;
	CGPoint spawnPosition;
	CGPoint velocity;
	BOOL affectedByForces;
	CCSprite* itemSprite;
}

@property TypeOfItem itemType;
@property int worth;
@property int tagNo;
@property float edibleTimer;
@property CGPoint spawnPosition;
@property CGPoint velocity;
@property BOOL affectedByForces;
@property (nonatomic,retain) CCSprite* itemSprite;

//PRESET POSITIONING & VELOCITY
+ (id) itemWithParentNode:(CCNode*)parentNode randomSpawnMethod:(WhereToSpawnItem)method isAffectedByForces:(BOOL)affected edibleInTime:(float)edibleTime;
- (id) initWithParentNode:(CCNode*)parentNode randomSpawnMethod:(WhereToSpawnItem)method isAffectedByForces:(BOOL)affected edibleInTime:(float)edibleTime;


//CUSTOM POSITIONING & VELOCITY
+ (id) itemWithParentNode:(CCNode*)parentNode initPosition:(CGPoint)definedPos initVelocity:(CGPoint)definedVel isAffectedByForces:(BOOL)affected edibleInTime:(float)edibleTime;
- (id) initWithParentNode:(CCNode*)parentNode initPosition:(CGPoint)definedPos initVelocity:(CGPoint)definedVel isAffectedByForces:(BOOL)affected edibleInTime:(float)edibleTime;

@end