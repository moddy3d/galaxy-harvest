//
//  PlayerAI.h
//  CoinCatch
//
//  Created by Richard Lei on 11-01-12.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "PlayerCharacter.h"

@interface PlayerAI : PlayerCharacter {

}

@end
