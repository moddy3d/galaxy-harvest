//
//  GameScene.h
//  CoinCatch
//
//  Created by Richard Lei on 11-01-06.
//  Copyright 2011 Creative Inventory Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"
#import "GameConfig.hpp"
#import "PlayerCharacter.h"
#import "ItemFactory.h"
#import "Items.h"
#import "AIBrain.h"
#import "PhysicsEngine.h"

@interface GameScene : CCLayer {

	// Game state
	GameState stateOfGame;
	
	// Time
	float realTimeElapsed;
	float gameTimer;

	// Physics Engine
	PhysicsEngine* physicsHandler;
	
	
	// Head Up Displays
	CCLabelTTF* gameTimeDisplay;
	CCLabelTTF* Player1ScoreDisplay;
	CCLabelTTF* Player2ScoreDisplay;
	CCLabelTTF* typeOfDeviceDisplay;
	
	// Buttons
	CCSprite* poundDownButton;

	
	// Character
	PlayerCharacter* Player1;
	PlayerCharacter* Player2;
	
	// Off screen indicators
	CCSprite* Player1OffScreenIndicator;
	CCSprite* Player2OffScreenIndicator;
	
	
	// AI brain
	AIBrain* brain;
	
	// Items
	CCArray* itemArray;
	ItemFactory* myItemFactory;	
}

@property GameState stateOfGame;
@property float realTimeElapsed;
@property float gameTimer;

+(id) scene;


@end
physi