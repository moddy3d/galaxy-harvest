//
//  ItemFactory.m
//  CoinCatch
//
//  Created by Richard Lei on 11-01-07.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "ItemFactory.h"

@implementation ItemFactory
@synthesize chanceForNothing, chanceForBronzeCoin, chanceForSilverCoin, chanceForGoldCoin,
			chanceForJadeCoin, chanceForIceCoin, chanceForRedBag,
			chanceForPoop, chanceForTimeExtension, timeSinceLastSpawn;

- (float) sumOfItemChances
{
	return	chanceForBronzeCoin + chanceForSilverCoin + chanceForGoldCoin + 
			chanceForJadeCoin + chanceForIceCoin + chanceForRedBag + chanceForPoop +
			chanceForTimeExtension;
}

- (void) updateItemRanges
{	
	for (int count = 0; count < NUMBER_OF_DIFFERENT_ITEMS; count++) {
		int sumY = 0;
		int sumX = 0;
		for (int subCount = count; subCount >= 0; subCount--) {
			sumY += chanceArray[subCount];
			if (subCount != count) {
				sumX += chanceArray[subCount];
			}
			rangeArray[count] = CGPointMake(sumX, sumY);
		}
	}

}

- (void) updateItemChances
{
	chanceArray[0] = chanceForBronzeCoin;
	chanceArray[1] = chanceForSilverCoin; 
	chanceArray[2] = chanceForGoldCoin; 
	chanceArray[3] = chanceForJadeCoin;
	chanceArray[4] = chanceForIceCoin;
	chanceArray[5] = chanceForRedBag;
	chanceArray[6] = chanceForPoop;
	chanceArray[7] = chanceForTimeExtension;
}

- (TypeOfItem) itemToSpawn:(float)realTime
{
	[self updateItemChances];
	[self updateItemRanges];
	
	TypeOfItem returnItemType;
	
	// IF NUMBER FALLS IN BETWEEN 98 - 100 THEN SPAWN AN ITEM
	if ((CCRANDOM_0_1() * 100) > chanceForNothing) 
	{
		float randomItemFloat = CCRANDOM_0_1() * [self sumOfItemChances];
		// USE ITEM RANGES TO DEFINE WHAT ITEM TO SPAWN
		for (int count = 0; count < NUMBER_OF_DIFFERENT_ITEMS; count++) 
		{
			// FIND WHAT ITEM IT IS IN RANGE OF
			if ((randomItemFloat > rangeArray[count].x) && (randomItemFloat < rangeArray[count].y)) 
			{
				returnItemType = (TypeOfItem) count;
			}
		}
	}
	else {
			returnItemType = NullItemID;
	}
	
	return returnItemType;
}

- (id) init
{
	if ((self = [super init]))
	{
		//
		// DEFAULT CHANCE FACTORS
		//
		
		// ROLL NOTHING
		chanceForNothing = 96.0f;
		
		// ROLL SOMETHING
		chanceForBronzeCoin = 50.0f;
		chanceForSilverCoin = 25.0f;
		chanceForGoldCoin = 10.0f;
		chanceForJadeCoin = 5.0f;
		chanceForIceCoin = 2.0f;
		chanceForRedBag = 1.0f;
		chanceForPoop = 10.0f;
		chanceForTimeExtension = 0.0f;
		
		[self updateItemChances];
		
		[self updateItemRanges];
		
		timeSinceLastSpawn = 0.0f;
	}
	return self;
}

- (void) dealloc
{
	[super dealloc];
}

@end
