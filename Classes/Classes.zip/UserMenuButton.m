//
//  UserMenuButton.m
//  CoinCatch
//
//  Created by Richard Lei on 11-01-06.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//


#import "UserMenuButton.h"
#import "LoadingScene.h"


@implementation UserMenuButton

@synthesize buttonSprite;


- (CGPoint) locationFromTouch:(UITouch*)touch
{
	CGPoint touchLocation = [touch locationInView: [touch view]];
	return [[CCDirector sharedDirector] convertToGL:touchLocation];
}

- (BOOL) ccTouchBegan:(UITouch *)touch withEvent:(UIEvent *)event
{
	CGPoint touchLocation = [self locationFromTouch:touch];
	BOOL isTouchHandled = CGRectContainsPoint([buttonSprite boundingBox], touchLocation);
	
	if (isTouchHandled)
	{
		[[CCDirector sharedDirector] replaceScene:[LoadingScene sceneWithTargetScene:targetedScene]];
	}
	return isTouchHandled;
}

- (void) update:(ccTime)delta
{
	
}

+ (id) buttonWithParentNode:(CCNode*)parentNode file:(NSString*)name tag:(TagID)tagID sceneToTarget:(TargetScenes)scene hasLoading:(BOOL)loading
{
	return [[[self alloc] initWithParentNode:parentNode file:name tag:tagID sceneToTarget:scene hasLoading:loading] autorelease];
}

- (id) initWithParentNode:(CCNode*)parentNode file:(NSString*)name tag:(TagID)tagID sceneToTarget:(TargetScenes)scene hasLoading:(BOOL)loading
{
	if ((self = [super init]))
	{
		// Init the button sprite
		buttonSprite = [CCSprite spriteWithFile:name];
		
		// Set scene to target
		targetedScene = scene;
		
		// Will there be a loading scene?
		hasLoadingScreen = loading;
		
		[parentNode addChild:buttonSprite z:GUILayer tag:tagID];
		
		[[CCScheduler sharedScheduler] scheduleUpdateForTarget:self priority:0 paused:NO];
		
		[[CCTouchDispatcher sharedDispatcher] addTargetedDelegate:self priority:-1 swallowsTouches:YES];
	}
	return self;
}

- (void) dealloc
{
	// Must manually unschedule, it is not done automatically! 
	[[CCScheduler sharedScheduler] unscheduleUpdateForTarget:self];
	// Must manually remove this class as touch input receiver! 
	[[CCTouchDispatcher sharedDispatcher] removeDelegate:self];
	[super dealloc];	
}


@end
