//
//  MenuScene.h
//  CoinCatch
//
//  Created by Richard Lei on 11-01-06.
//  Copyright 2011 Creative Inventory Ltd.. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"
#import "GameConfig.hpp"
#import "UserMenuButton.h"
#import "PlayerCharacter.h"


@interface MenuScene : CCLayer 
{
	CCMultiplexLayer* mpLayer;
	
	// lang select layer
	CCLayer* languageSelectionLayer;
	CCMenuItemImage* englishButton;
	CCMenuItemImage* chineseButton;
	
	// main menu layer
	CCLayer* mainMenuLayer;
	CCMenuItemImage* startButton;
	CCMenuItemImage* optionsButton;
	
	// options menu layer
	CCLayer* optionsMenuLayer;
	CCMenuItemToggle* soundToggle;
	CCMenuItemToggle* musicToggle;
	CCMenuItemImage* creditsButton;
	CCMenuItemImage* resetScoreButton;
	CCMenuItemToggle* languageToggle;
	CCMenuItemImage* backToMainMenuButton;
		
	CCLabelTTF* gameTitle;
}

+ (id) scene;

@end
